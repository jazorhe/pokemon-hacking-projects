unLZ-GBA PublicBeta readme
------------------
(C) 2003-2004 by loadingNOW

History
------------------
About a year ago i released Pokepic, which was basicly a lz77 decompressor/compressor 
with a small part of gba gfx core to display gba gfx - the pokemon images that is.
While it was nice it was very limited (to few images of one game) so this time it's
basicly the same but with a scranner to work with more - most lz77 games.

How to use
------------------
Open File. The Programm will search for LZ77 compressed data. Once that's finished
it will display the data. Note: It will usually not guess the right palettes this
depends on the game.
If the Program does NOT find any GFX you may run Deep Scan. This will make sure
you get to see anything wich could be interpreted as lz77 data. However it will show
you MUCH mor garbage so it's NOT recommented unless you REALLY need it (which might be
the case with a few square games).

NOT THAT THIS IS BETA SOFTWARE. THERE MIGHT BE BUGS AND THE PROGRAM MIGHT NOT RUN ON
YOUR MACHINE OR CRASH.

BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE PROGRAM, TO 
THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE 
COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY 
KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND
PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE 
COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. 

You are permitted to reverse this software like any other software you have the license to 
use. While this is nothing special I note it anyway to encourage you to use the software
in any way you want to. You may even release your modded version with this binary not
just your patch alone - as long as you do not remove any copyrights and/or this document.

I didn't release the source this time because it is horribly messy
and i don't have the time to clean it up. (Besides noone actually used the PokepicSource)

Thanks to
-------------------
PokemonHacker for the idea and many other things
Filb because he did some major betatesting
All other Betatesters expecially xdaniel and wolfsclaw
Forgotten for VBA(-SDL)
